// This script file is licensed under a Creative Commons
// Attribution 4.0 International License (cc by 4.0):
// http://creativecommons.org/licenses/by/4.0/
// You may adapt and/or share this script file for any purpose,
// provided you give credit to http://bridgecomposer.com

//  This script checks for Auction or Play "Notes" that exceed 128 characters.
//  Such Notes cause the file to fail to export to LIN format,
//  getting a BFC error "data too long".

//  $Id: BFCcheck.js 77 2021-10-11 22:21:10Z Ray $

var nSelect = -1;
var iBoard = 0;

function Exit()
{
  if (nSelect >= 0) {
    bc.SelectedBoard = nSelect;
    bc.Save();
  }

  WScript.Quit(0);
}

function CheckNotes(bd, nSection)
{
  var notes = (nSection) ? bd.PlayNotes : bd.AuctionNotes;
  while (notes.MoveNext()) {
    var strNote = notes.Current.value;
    if (strNote.length > 128) {
      if (nSelect < 0)
        nSelect = iBoard;

      var strMsg = 'Board ' + bd.UniqueBoard + ': ' + ((nSection) ? 'Play' : 'Auction') +
      ' Note "' + strNote.substr(0, 20) + '..." is ' + strNote.length +
      ' characters long,\nexceeding the BFC maximum of 128 characters';

      if (!bc.confirm(strMsg, 16))
        Exit();
    }
  }
}

var bc = WScript.CreateObject('BridgeComposer.Object');
if (WScript.Arguments.length > 0 && WScript.Arguments(0) !== '-') {
  bc.Open(WScript.Arguments(0));
} else {
  if (!bc.Open()) WScript.Quit();
}

var bds = bc.Boards;
while (bds.MoveNext()) {
  var bd = bds.Current;
  CheckNotes(bd, 0);
  CheckNotes(bd, 1);
  ++iBoard;
}

if (nSelect < 0)
  bc.alert("BFCcheck: No problems found", 64);

Exit();
