The files in this directory (CDT) are sub-scripts included by ..\CreateDealType.wsf.

They are not scripts that are designed to run stand-alone.
