/*  You may add additional deal type filters below.

Example filter:
(See https://bridgecomposer.com/Info/CreateDealType.htm for instructions.)

DefineFilter(CDT1, 'Strong 1NT Opener', 'Game-Going or Better Response',
function()
{
  if (S.hcp < 15 || S.hcp > 17) return false; // South not 15-17 HCP
  if (N.hcp < 10) return false; // North has less than 10 HCP
  if (!S.isBalanced()) return false; // South not balanced
  if (S.suit[SPADES].length >= 5 ||
    S.suit[HEARTS].length >= 5) return false; // South has a 5-card major
    
  strAuction = '1NT';
  return true;
});

*/
