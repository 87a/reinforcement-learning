// This script file is licensed under a Creative Commons
// Attribution 4.0 International License (cc by 4.0):
// http://creativecommons.org/licenses/by/4.0/
// Copyright (C) 2021 http://bridgecomposer.com
// Portions licensed under the Apache License, Version 2.0:
// http://www.apache.org/licenses/LICENSE-2.0

//  This script formats a team competition.
//  Each board in the competition is of course played twice, resulting in
//  two board objects in the input file.
//  These two board objects are formatted into a single column on a page
//  (space permitting), two columns per page.
//  The hand diagram is shown once, followed by the bidding and play
//  for both the Open room and the Closed room.
//  The final commentary of the second board object is updated to
//  show the imp score running totals.

//  The two board objects may overflow a single column, due to
//  a combination of a long auction, a lot of alerts, and a lack of
//  early claim or concession for one or both board objects.
//  In this case the two board objects will be split into two columns
//  with the first column on a new page.

//  $Id: FormatMatch.js 70 2021-09-23 14:12:12Z Ray $


//  The script will prompt for an optional "player name map" file.
//
//  The file should contain lines like the following:
//  jfk35 => Kennedy, J.
//  which would replace all occurrences of "jfk35" in the
//  player name fields with "Kennedy, J.".
//
//  The default field splitter (space, equals, greater-than, space)
//  may be changed, see strPlayerMapSplitter, below.
//
//  This text file must have UTF-8 encoding by default,
//  see objStream.CharSet, below.
//
//  When a file has been selected, it will be remembered
//  and not prompted for again.
//
//  To suppress player name mapping (and the prompt for the file),
//  specify the "n" argument.
//
//  To reset the remembered file location, run (from a command prompt):
//  FormatMatch.js - r
//
//  To minimize prompting, specify the "q" (for "quiet") option.

var strPlayerMapSplitter = ' => ';


var OVERFLOWLINES = 41;             // controls split of closed room to a new column


var MB_ICONERROR = 16;
var MB_ICONWARNING = 48;

var SHOW_DIAGRAM = 0x8;
var SHOW_DIAGRAMCMTY = 0x40;
var SHOW_AUCTIONCMTY = 0x80;
var CMTY_FINAL = 3;
var INVALID_SCORE = -999999;
var NORTH = 0;
var EAST = 1;
var SOUTH = 2;
var WEST = 3;
var NHANDS = 4;

var arrPosition = ['North', 'East', 'South', 'West'];
var arrTeam = [];


// Google StringMap
// Modified by bridgecomposer.com to run on Microsoft JScript 5.812
// Copyright (C) 2011 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * @fileoverview Implements StringMap - a map api for strings.
 *
 * @author Mark S. Miller
 * @author Jasvir Nagra
 * @overrides StringMap
 */

var StringMap;

(function() {
   "use strict";

   var freeze = function freeze(x) { return x; }    // "freeze" not impl
   function constFunc(func) {
     func.prototype = null;
     return freeze(func);
   }

   function assertString(x) {
     if ('string' !== typeof(x)) {
       throw new TypeError('Not a string: ' + String(x));
     }
     return x;
   }

   StringMap = function() {

     var objAsMap = {};

     return freeze({
       get: constFunc(function(key) {
         return objAsMap[assertString(key) + '$'];
       }),
       set: constFunc(function(key, value) {
         objAsMap[assertString(key) + '$'] = value;
       }),
       has: constFunc(function(key) {
         return (assertString(key) + '$') in objAsMap;
       }),
       'delete': constFunc(function(key) {
         return delete objAsMap[assertString(key) + '$'];
       })
     });
   };

 })();
//  (End of [modified] Google StringMap)


function GetPlayerMapPath(bReset)
{
  var pathRValue = 'HKCU\\SOFTWARE\\Bridge Club Utilities\\BCScript\\FormatMatch\\PlayerMapPath';

  var pathMap = '';
  try {
    pathMap = wsh.RegRead(pathRValue);
    if (!bReset)
      return pathMap;
  }
  catch (ex) {}

  var strFilter = 'Text Files (*.txt)|*.txt|All Files (*.*)|*.*||';
  pathMap = bc.BrowseForFile('Open Player Name Map', 0, strFilter, pathMap);
  if (!pathMap)
    return null;

    wsh.RegWrite(pathRValue, pathMap);
    return pathMap;
}

 
function MapPlayerNames(pathname, splitter)
{
  var objStream = WScript.CreateObject('ADODB.Stream');
  objStream.CharSet = 'utf-8';
  objStream.Open();
  objStream.LoadFromFile(pathname);
  var strText = objStream.ReadText();
  objStream.Close();
  
  var mapPlayer = new StringMap;
  for (var iLine = 0; iLine < strText.length;) {
    var iEnd = strText.indexOf('\n', iLine);
    if (iEnd < 0)
      break;
      
    var iLimit = iEnd;
    if (iLimit > iLine && strText.charAt(iLimit - 1) === '\r')
      --iLimit;
    
    var iSplit = strText.indexOf(splitter, iLine);
    if (iSplit >= iLine && iSplit < iLimit) {    
      var strFind = strText.substring(iLine, iSplit);
      strFind = strFind.toUpperCase();
      var strReplace = strText.substring(iSplit + splitter.length, iLimit);
      mapPlayer.set(strFind, strReplace);
    } else {
      //  no splitter on the line
    }
    
    iLine = iEnd + 1;
  }
  
  var NHANDS = 4;
  var arrTag = ['West', 'North' , 'East', 'South'];
  var mapUnmapped = new StringMap;
  var arrUnmapped = [];
  
  var bds = bc.Boards;
  while (bds.MoveNext()) {
    var bd = bds.Current;
    for (var iHand = 0; iHand < NHANDS; ++iHand) {
      var strTag = arrTag[iHand];
      var strFind = bd.TagValue(strTag);
      var strUpper = strFind.toUpperCase();
      var strLower = strFind.toLowerCase();
      if (mapPlayer.has(strUpper)) {
        var strReplace = mapPlayer.get(strUpper);
        bd.TagValue(strTag) = strReplace;
      } else if (!mapUnmapped.has(strLower)) {
        mapUnmapped.set(strLower, '');
        arrUnmapped.push(strLower);
      }
    }
  }
  
  if (!bQuiet && arrUnmapped.length) {
    var str = 'Unmapped player names:';
    arrUnmapped.sort(function(a,b)
    {
      var lowa = a.toLocaleLowerCase();
      var lowb = b.toLocaleLowerCase();
      return lowa.localeCompare(lowb);
    });
    
    for (var i in arrUnmapped) {
      str += '\n' + arrUnmapped[i];
    }
    
    if (!bc.confirm(str))
      WScript.Quit();
  }
}

function GetBC(minver)
{
  minver = minver || '5.61';  // default if "minver" omitted
  try {
    var bc = WScript.CreateObject('BridgeComposer.Object');
  } catch (e) {
    WScript.Echo('To run this script, you need to install BridgeComposer ' +
      '(version ' + minver + ' or later).\r\n\r\n' +
      'Visit https://bridgecomposer.com and click "Download Now".');
    WScript.Quit(1);
  }
  
  var arrMin = minver.split('.');
  while (arrMin.length < 3)
    arrMin.push(0);
  
  var arrNow = bc.Version.split('.');
  while (arrNow.length < 3)
    arrNow.push(0);
  
  for (var i = 0; i < 3; ++i) {
    if (arrNow[i] > arrMin[i])
      break;
    
    if (arrNow[i] < arrMin[i]) {
      bc.alert('To run this script, you need to update BridgeComposer ' +
        'to version ' + minver + ' or later.\n\n' +
        'In BridgeComposer, use the "Help>Check For Updates" menu command.',
        MB_ICONERROR);
      WScript.Quit(1);
    }
  }
  
  return bc;
}

var implimit = [10, 40, 80, 120, 160, 210, 260, 310, 360, 420, 490, 590,
  740, 890, 1090, 1290, 1490, 1740, 1990, 2240, 2490, 2990, 3490, 3990];
  
function IMPS(score) {
  var imps = 0;
  var a = Math.abs(score);
  if (a >= 4000) imps = 24;
  else {
    for (var ix in implimit) {
      if (a <= implimit[ix]) {
        imps = +ix;
        break;
      }
    }
  }
  if (score < 0) imps = -imps;
  return imps;
}

function CountSectionLines(bd, tag)
{
  var ctok = 0;
  var str = bd.TagSection(tag);
  var vtok = str.match(/\S+/g);
  if (vtok) {
    for (var i = 0; i < vtok.length; ++i) {
      var tok = vtok[i];
      var ch = tok.charAt(0);
      if (ch === '=' || ch === '$')
        continue;   // note reference or numeric annotation glyph
      
      ++ctok;
    }
  }
  
  if (tag === 'Auction') {
    var str = bd.TagValue(tag);
    var ix = 'WNES'.indexOf(str);
    if (ix > 0)
      ctok += ix;   // count blank spaces in first line of Auction
  }
  
  var clines = Math.floor((ctok + 3) / 4);
  return clines;
}

function PromptTeam(iTeam)
{
  var obj = arrTeam[iTeam];
  if (bQuiet && obj.name.length > 0)
    return;
  
  var strPlayers = '';
  for (var i = 0, j = NORTH; i < NHANDS; ++i) {
    if (i > 0)
      strPlayers += ', ';
    
    strPlayers += obj.player[j];
    j += 2;
    if (j >= NHANDS)
      j = EAST;
  }
  
  var str = 'Enter team name for ' + strPlayers;
  str += '\nOptionally append ",score" for carryover';
  var strDefault = obj.name;
  if (obj.score) {
    strDefault += ', ' + obj.score;
  }
  
  var strTeam = bc.prompt(str, strDefault);
  if (!strTeam)
    WScript.Quit();
  
  var ix = strTeam.lastIndexOf(',');
  if (ix > 0) {
    var strScore = strTeam.substr(ix + 1);
    obj.score = parseInt(strScore);
    strTeam = strTeam.substr(0, ix);
  } else {
    obj.score = 0;
  }
  
  obj.name = strTeam;    
}


//  Begin execution here

var wsh = WScript.CreateObject('WScript.Shell');
var fso = WScript.CreateObject('Scripting.FileSystemObject');
var bc = GetBC('5.85');
var bOpen = false;
if (WScript.Arguments.length > 0 && WScript.Arguments.Item(0) !== '-') {
  bc.Open(WScript.Arguments(0));
  bOpen = true;
}

var bReset = false;
var bNomap = false;
var bQuiet = false;
if (WScript.Arguments.length > 1) {
  var strOptions = WScript.Arguments.Item(1);
  bReset = strOptions.indexOf('r') >= 0;
  bNomap = strOptions.indexOf('n') >= 0;
  bQuiet = strOptions.indexOf('q') >= 0;
}

if (!bNomap) {
  //  Apply the player name map file, if it exists

  var pathAbs = GetPlayerMapPath(bReset);
  if (bReset)
    WScript.Quit();
}

if (!bOpen) {
  if (!bc.Open())
    WScript.Quit();
  
  bOpen = true;
}

bc.SortAllBoardsByNumber();
var bds = bc.Boards;

//  Remove any blank spacer boards inserted by previous runs of this script

for (var ibd = bds.Count - 1; ibd >= 0; --ibd) {
  var bd = bds.Item(ibd);
  var bDelete = false;
  do {
    var tagDeal = bd.TagValue('Deal');
    if (tagDeal.length !== 0)
      break;
    
    var tagEvent = bd.TagValue('Event');
    if (tagEvent.length !== 0)
      break;
      
    var strCmt = bd.Commentary(CMTY_FINAL);
    if (strCmt.length !== 0)
      break;
      
    bDelete = true;
      
  } while (false);
    
  if (bDelete) {
    bc.DeleteBoard(ibd);
  }
}

//  Check document length

if (bds.Count < 2) {
  bc.alert('The input file has fewer than 2 boards', MB_ICONERROR);
  WScript.Quit(1);
}

if (pathAbs && fso.FileExists(pathAbs)) {
  MapPlayerNames(pathAbs, strPlayerMapSplitter);
}

//  Initialize the two team objects

for (var iTeam = 0; iTeam < 2; ++iTeam) {
  var strName = 'Team' + (iTeam + 1);
  var obj = {name: strName, score: 0, player: []};
  arrTeam[iTeam] = obj;
}

for (var ibd = 0; ibd < 2; ++ibd) {
  var bd = bds.Item(ibd);
  for (var i = 0; i < NHANDS; ++i) {
    var iTeam = (i & 1) ? 1 - ibd : ibd;
    arrTeam[iTeam].player[i] = bd.TagValue(arrPosition[i]);
  }
  
  if (ibd === 0) {
    var strTeam = bd.TagValue('HomeTeam');
    if (strTeam)
      arrTeam[0].name = strTeam;
    
    var strTeam = bd.TagValue('VisitTeam');
    if (strTeam)
      arrTeam[1].name = strTeam;
    
    var strScore = bd.TagValue('HomeTeamCarryover');
    arrTeam[0].score = +strScore;
    
    var strScore = bd.TagValue('VisitTeamCarryover');
    arrTeam[1].score = +strScore;
  }
}

for (var iTeam = 0; iTeam < 2; ++iTeam) {
  PromptTeam(iTeam);
}

//  Setup the page header

var bd = bds.Item(0);
var strHead = bd.TagValue('Event');

if (strHead === '') {
  strHead = arrTeam[0].name + ' v ' + arrTeam[1].name;
} else {
  if (strHead.substr(0, 3).toLowerCase() === '<u>') {
    strHead = strHead.substr(3);
  }
  
  if (strHead.substr(strHead.length - 4).toLowerCase() === '</u>') {
    strHead = strHead.substr(0, strHead.length - 4);
  }
  
  if (strHead.indexOf(' v ') < 0) {
    strHead += ': ' + arrTeam[0].name + ' v ' + arrTeam[1].name;
  }
}

if (!bQuiet) {
  strHead = bc.prompt('Enter the page header text', strHead);
  if (strHead === null)
    WScript.Quit();
}

if (strHead.substr(0, 3).toLowerCase() !== '<u>')
  strHead = '<u>' + strHead;

if (strHead.substr(-4).toLowerCase() !== '</u>')
  strHead = strHead + '</u>';

bd.TagValue('Event') = strHead;

//  Process all boards

var nScoreOpen = 0;
var nLinesOpen = 0;
var nDataBoards = 0;
var nPagePos = 0; // position on page (0-3): left top, left bottom, right top, right bottom
for (var ibd = 0; ibd < bds.Count; ++ibd) {
  var bd = bds.Item(ibd);
  var bClosed = nDataBoards & 1;
  var strExpect = bClosed ? 'Closed' : 'Open';
  var tagRoom = bd.TagValue('Room');
  if (tagRoom !== strExpect) {
    var str = "Board " + bd.UniqueBoard + ": Room Expected='" + strExpect + "' Found='" + tagRoom + "'";
    bc.alert(str, MB_ICONERROR);
    WScript.Quit(1);
  }
  
  ++nDataBoards;

  if (ibd > 0)
    bd.TagValue('Event') = '';
  
  var strSouth = bd.TagValue('South');
  if (strSouth === '') {
    var str = "Board " + bd.UniqueBoard + ": South player name is empty";
    bc.alert(str, MB_ICONERROR);
    WScript.Quit(1);
  }
  
  //  Determine the team sitting NS
  
  var iTeam;
  for (iTeam = 0; iTeam < 2; ++iTeam) {
    if (strSouth === arrTeam[iTeam].player[SOUTH])
      break;
  }
  
  if (iTeam > 1) {
    var str = "Board " + bd.UniqueBoard + ": New player sitting South: " + strSouth;
    str += '\nEnter team: 1=' + arrTeam[0].name + ', 2=' + arrTeam[1].name;
    for (;;) {
      var n = bc.prompt(str);
      if (n === null)
        WScript.Quit();
      
      iTeam = parseInt(n) - 1;
      if (iTeam >= 0 && iTeam <= 1)
        break;
    }
    
    arrTeam[iTeam].player[SOUTH] = strSouth;
  }
  
  //  Count lines in Auction and Play, including Notes
  //  (N.B. Does not account for notes that exceed a single line)
  
  var nLines = CountSectionLines(bd, 'Auction');
  var notesA = bd.AuctionNotes;
  nLines += notesA.Count;
  nLines += CountSectionLines(bd, 'Play');
  var notesP = bd.PlayNotes;
  nLines += notesP.Count;
  
  //  Determine the raw score
  
  var iDir = -1;
  var nScore = INVALID_SCORE;
  var tagScore = bd.TagValue('Score');
  if (tagScore === '') {
    // apparently a pass-out
    nScore = 0;
    iDir = 0;
  } else {
    var arScore = tagScore.split(' ');
    if (arScore.length === 2) {
      if (arScore[0] === 'NS') iDir = 0;
      else if (arScore[0] === 'EW') iDir = 1;
      nScore = parseInt(arScore[1]);
    }
  }
  
  if (iDir < 0 || nScore === INVALID_SCORE) {
    var str = "Board " + bd.UniqueBoard + ": Unexpected Score tag value '" + tagScore + "'";
    bc.alert(str, MB_ICONWARNING);
    nScore = 0;
    iDir = 0;
  } else {
    if (iDir) iTeam = 1 - iTeam;
    if (nScore < 0) {
      iTeam = 1 - iTeam;
      nScore = -nScore;
    }
  }
  
  //  Compute the imp score for the board, closed vs. open play
          
  if (!bClosed) {
    nScoreOpen = (iTeam === 0) ? nScore : -nScore;
    nLinesOpen = nLines;
    bd.Commentary(CMTY_FINAL) = '';
  } else {
    nScore = (iTeam === 0) ? -nScore : nScore;
    var nNet = nScoreOpen - nScore;
    iTeam = 0;
    if (nNet < 0) {
      iTeam = 1;
      nNet = -nNet;
    }
    
    var nImps = IMPS(nNet);      
    var strComment = '\\n';
    if (nImps !== 0)
      strComment += arrTeam[iTeam].name + ' +' + nImps + ' imps\\n';

    arrTeam[iTeam].score += nImps;
    strComment += '<b>' + arrTeam[0].name + ':</b> ' + arrTeam[0].score + 
      ' \u2014 <b>' + arrTeam[1].name + ': </b>' + arrTeam[1].score;
      
    bd.Commentary(CMTY_FINAL) = strComment;
  }
  
  //  Adjust the board "show flags"

  var nFlags = parseInt(bd.TagValue('BCFlags'), 16);
  nFlags |= SHOW_DIAGRAM;
  nFlags &= ~(SHOW_DIAGRAMCMTY | SHOW_AUCTIONCMTY);
  
  if (bClosed)
    nFlags &= ~SHOW_DIAGRAM;
  else
    nFlags |= SHOW_DIAGRAMCMTY;   // blank line between Diagram and Auction
    
  nFlags |= SHOW_AUCTIONCMTY;     // blank line betweein Auction and Play
  bd.TagValue('BCFlags') = nFlags.toString(16);
  
  //  If page overflow, reposition boards by inserting blank spacer boards:
  //    If right-hand column, move both boards to left-hand column on a new page
  //    Move closed board to top of right-hand column; add spacer below
  
  if (bClosed) {
    if ((nPagePos & 1) && nLines + nLinesOpen >= OVERFLOWLINES) {
      if (nPagePos === 3) {
        //  Bottom-right: insert two spacers before previous (open) board
        //  to force both boards to a new page
        
        bc.NewBoard(ibd - 1);   // spacer #1
        bc.NewBoard(ibd - 1);   // spacer #2
        ibd += 2;   // reposition to current board
      }
      
      //  Bottom-left: insert one spacer before current (closed) board
      //  to force it to top-right
      
      bc.NewBoard(ibd);   // insert spacer before current board
      ++ibd;              // reposition to current board      
      if (ibd < bds.Count - 1) {
        bc.NewBoard(ibd + 1);   // insert spacer after current board
        ++ibd;                  // reposition to new spacer board
        nPagePos = 3;
      }
    }
  }
  
  nPagePos = (nPagePos + 1) & 3;
}

//  Set the document layout options

var pathTemp = fso.GetSpecialFolder(2);
var pathLayout= pathTemp + '\\{3F92E03B-BD23-4501-99B6-921951DC8AFE}.pbn';
var ts = fso.CreateTextFile(pathLayout);
ts.WriteLine('%BCOptions ShowHCP PageHeader STBorder STShade');
ts.WriteLine('%BoardsPerPage 122');
ts.WriteLine('%EventSpacing 5');
ts.WriteLine('%Font:Commentary "Arial",10,400,0');
ts.WriteLine('%Font:Diagram "Arial",9,400,0');
ts.WriteLine('%Font:Event "Arial",12,700,0');
ts.WriteLine('%GutterSize 500,250');
ts.WriteLine('%Margins 500,500,500,120');
ts.WriteLine('%PdfOptions Eval');
ts.Close();
bc.LoadLayout(pathLayout);
fso.DeleteFile(pathLayout);
bc.Save();
