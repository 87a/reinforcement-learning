// This script file is licensed under a Creative Commons
// Attribution 4.0 International License (cc by 4.0):
// http://creativecommons.org/licenses/by/4.0/
// You may adapt and/or share this script file for any purpose,
// provided you give credit to http://bridgecomposer.com

//		2021-03-29: Use of this function is no longer recommended.
//		Use the BC object "GetDealer" method itstead.
//
//  This "includable" script implements a getRandomBoard() function.
//  getRandomBoard() returns a Board object with a random Deal tag.
//  For efficiency, it generates random deals in batches.
//  It will use either the BridgeComposer generator or the BigDeal generator,
//  depending whether the BridgeComposer Edit>Options BigDeal folder is set.
//
//  Revised 5/12/2018

var getRandomBatch = 64;
var getRandomDD = false;

var getRandomBoard = (function() {
  var nUsed = getRandomBatch;
  var bcRandom = WScript.CreateObject('BridgeComposer.Object');
  bcRandom.Noui = true;
  return function() {
    if (nUsed >= getRandomBatch) {
      bcRandom.New();
      bcRandom.GenerateRandomBoards(getRandomBatch);
      if (getRandomDD) bcRandom.DoubleDummyAllBoards();
      nUsed = 0;
    }
    var brds = bcRandom.Boards;
    var brd = brds.Item(nUsed++);
    return brd;
  }
}());
