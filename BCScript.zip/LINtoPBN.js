// This script file is licensed under a Creative Commons
// Attribution 4.0 International License (cc by 4.0):
// http://creativecommons.org/licenses/by/4.0/
// You may adapt and/or share this script file for any purpose,
// provided you give credit to http://bridgecomposer.com

//  This script scans a folder for LIN files
//  and converts them to PBN files.

//  $Id: LINtoPBN.js 53 2021-06-15 13:08:33Z Ray $


var MB_ICONINFORMATION = 64;
var MB_ICONWARNING = 48, MB_ICONEXCLAMATION = 48;
var MB_ICONERROR = 16, MB_ICONSTOP = 16;
var MB_YESNO = 4;
var MB_RETRYCANCEL = 5;
var MB_DEFBUTTON2 = 256;
var BCP_UPDATE = 0; // update progress
var BCP_TITLE = 1;  // set progress panel title
var BCP_CLOSE = 2;  // close progress panel
var BCP_BUTTON = 3; // set button label


function Exit(rc)
{
  bc.progress(BCP_CLOSE);
  var disp = (rc) ? "canceled" : "complete";
  bc.alert('LINtoPBN ' + disp + ': ' + nFind + ' converted\n' + strFind, MB_ICONINFORMATION);
  WScript.Quit(rc);
}

function ScanFolder(fldr)
{
  //if (!bc.confirm('Scanning folder ' + fldr.Self.Path, 0)) WScript.Quit();
  var items = fldr.Items();
  for (var i = 0; i < items.Count; ++i) {
    var item = items.Item(i);
    if (item.IsFolder) {
      if (bSubfolders) {
        var fname = item.Name;
        var ixx = fname.lastIndexOf('.');
        if (ixx >= 0) {
          var ftype = fname.slice(ixx + 1);
          ftype = ftype.toLowerCase();
          if (ftype === 'zip' || ftype === 'cab') continue;
        }

        ScanFolder(item.GetFolder);
      }
    } else {
      ScanFile(item);
    }
  }
}

function ScanFile(item)
{
  //if (!bc.confirm('Scanning file ' + item.Path, 0)) WScript.Quit();
  var fname = item.Name;
  if (!bc.progress(BCP_UPDATE, 'Scanning ' + item.Path + '\n' + nFind + ' found')) Exit(1);
  var ixx = fname.lastIndexOf('.');
  if (ixx < 0) return;
  var ftype = fname.slice(ixx + 1);
  ftype = ftype.toLowerCase();
  if (ftype !== 'lin') return;
  var fpath = item.Path;
  try {
    bc.Open(fpath);
  } catch(ex)
  {
    return;
  }

  var npath = fpath.substr(0, fpath.length - 3) + 'pbn';
  if (fso.FileExists(npath)) {
    var str = 'The file ' + npath + ' already exists.' +
      '\n\nDo you wish to overwrite it?';
    var rc = bc.confirm(str);
    if (!rc)
      return;
    
    fso.DeleteFile(npath);
  }

  bc.DoubleDummyAllBoards();
  bc.SaveAs(npath);
  ++nFind;
}

var bc = WScript.CreateObject('BridgeComposer.Object');
if (WScript.Arguments.length > 0)
  bc.Open(WScript.Arguments.Item(0));  // for dialog positioning

var nFind = 0;
var sh = WScript.CreateObject('Shell.Application');
var fso = WScript.CreateObject('Scripting.FileSystemObject');
var strFldr = bc.BrowseForFolder('LINtoPBN: Folder to scan');
if (!strFldr)
  WScript.Quit();

var fldr = sh.NameSpace(strFldr);  // convert string path into Folder object
var bSubfolders = bc.confirm('LINtoPBN: Scan subfolders?', MB_ICONINFORMATION | MB_YESNO | MB_DEFBUTTON2);
bc.progress(BCP_TITLE, 'LINtoPBN');
var strFind = '';
ScanFolder(fldr);
Exit(0);
